/*BY SUBMITTING THIS FILE TO CARMEN, I CERTIFY THAT I STRICTLY ADHERED TO THE
TENURES OF THE OHIO STATE UNIVERSITY’S ACADEMIC INTEGRITY POLICY.
THIS IS THE README FILE FOR LAB 3. */

void readAndPop(char ***titles, int number);
void readAndPopFave(char ****best, char ***titles, int number, int fave);
void printFile(char ***titles, char ****best, int number, int fave);
